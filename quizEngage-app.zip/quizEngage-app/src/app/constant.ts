export class AppConstant {
    // Authentication Mock constants values

    public static MIN_YEAR: number = 100;

}
